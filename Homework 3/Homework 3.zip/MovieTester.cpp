#include <iostream>
#include <string>
#include "Movie.h"
using namespace std;
int main(void)
{
	Movie();
}
